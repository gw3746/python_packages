# con2mailserver/__init__.py
from .con2mailserver import con2gmailserver, con2hinetserver, con2mailserver,test_conect_test